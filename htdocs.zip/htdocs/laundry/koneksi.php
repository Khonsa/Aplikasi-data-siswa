<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "DB_laundry";

$konek = mysqli_connect($host, $user, $pass, $db) or die("Database MYSQL Tidak Terhubung");