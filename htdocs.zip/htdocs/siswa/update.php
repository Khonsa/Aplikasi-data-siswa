<?php
require("koneksi.php");

$response = array();

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $id = $_POST["id"];
    $nama = $_POST["nama"];
    $nim = $_POST["nim"];
    $angkatan = $_POST["angkatan"];
    $jurusan = $_POST["jurusan"];
    $prodi = $_POST["prodi"];

    $perintah = "SELECT FROM tbl_siswa";
    $eksekusi = mysqli_query($konek, $perintah);
    $cek = mysqli_affected_rows($konek);

    if($cek>0){
        $response["kode"] = 1;
        $response["pesan"] = "Ada Data";
    }else{
        $response["kode"] = 0;
        $response["pesan"] = "Tidak ada Data";
    }
}else{
    $response["kode"] = 0;
    $response["pesan"] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($konek);