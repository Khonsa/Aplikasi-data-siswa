package com.example.datasiswa.API;

import com.example.datasiswa.Model.ResponseModel;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface APIRequestData {
    @GET("retrieve.php")
    Call<ResponseModel> ardRetrieveData();

    @FormUrlEncoded
    @POST("create.php")
    Call<ResponseModel> ardCreateData(
            @Field("nama") String nama,
            @Field("nim") String nim,
            @Field("angkatan") String angkatan,
            @Field("jurusan") String jurusan,
            @Field("prodi") String prodi
    );

    @FormUrlEncoded
    @POST("delete.php")
    Call<ResponseModel> ardDeleteData(
            @Field("id") int id
    );

    @FormUrlEncoded
    @PUT("update.php")
    Call<ResponseModel> ardUpdateData(
            @Path("id") int id,
            @Field("nama") String nama,
            @Field("nim") String nim,
            @Field("angkatan") String angkatan,
            @Field("jurusan") String jurusan,
            @Field("prodi") String prodi
    );
}
